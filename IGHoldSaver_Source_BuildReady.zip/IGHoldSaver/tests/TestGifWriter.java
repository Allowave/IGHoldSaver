import com.example.igholdsaver.GifWriter;
import java.io.*;
public class TestGifWriter {
  public static void main(String[] args) throws Exception {
    try (GifWriter writer = new GifWriter(new FileOutputStream(args[0]), 128, 96)) {
       for(int f=0;f<3;f++) {
         int[] a=new int[128*96];
         for(int y=0;y<96;y++)for(int x=0;x<128;x++)
            a[y*128+x] = 0xff000000 | (((x*2+f*50)&255)<<16) | (((y*3+f*20)&255)<<8) | ((x+y+f*70)&255);
         writer.addFrame(a, 15);
       }
    }
  }
}
