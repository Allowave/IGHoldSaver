GIF 인코더 검증: `javac -d out app/src/main/java/com/example/igholdsaver/GifWriter.java tests/TestGifWriter.java && java -cp out TestGifWriter /tmp/test.gif`

GIF가 실제 디코딩되는지 `Pillow` 또는 이미지 뷰어로 확인하세요. Android 전체 프로젝트는 SDK와 Gradle 도구가 필요합니다.
