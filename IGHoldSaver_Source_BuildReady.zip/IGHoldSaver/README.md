# 인스타 저장 도우미 — IG Hold Saver (Android)

> **상태: 소스 코드 / 미빌드·미검증 프리뷰**. 이 저장소에는 `apk` 바이너리가 포함되어 있지 않습니다. 실제 기기와 인스타그램의 현재 화면 구조에서 동작 확인이 필요합니다.

## 기능

- 인스타그램 게시물 URL을 Android **공유 → 인스타 저장 도우미**로 받아 인앱 웹뷰에서 열기
- 앱 안에서 인스타그램 피드의 미디어를 **약 0.6초 길게 누르면** 미디어 추출 후 저장창 표시
- **계정명 표시** 설정: 사진은 원본 이미지 위에 명칭을 합성, 영상(MP4)은 Media3 Transformer 영상 오버레이를 합성
- **원본 MP4** 또는 **GIF** 저장 선택. GIF는 첫 12초, 6 fps, 최대 긴 변 480픽셀, 무음
- `갤러리/사진/IGHoldSaver` 또는 `갤러리/동영상/IGHoldSaver` 폴더에 저장
- 로그인 정보 별도 서버 전송 없음. Android WebView 세션 쿠키는 단말기에 보관.

## 중요한 동작 제한

- 이 앱은 **공식 인스타그램 앱의 롱프레스 기능을 교체하지 않습니다**. 안드로이드의 앱 샌드박스 때문에 타사 앱의 길게 누르기 동작을 일반 APK가 바꿀 수 없습니다. **이 앱 안에 표시된 인스타그램 웹뷰에서** 길게 누르는 방식입니다.
- 인스타그램 웹사이트가 DOM에 노출한 HTTPS 이미지/영상 주소를 읽는 방식이라 **항상 동작하는 다운로드 앱은 아닙니다**. Instagram 웹뷰 로그인, 비공개 게시물, DRM/`blob:` 영상, 미디어 URL이 숨겨진 피드, 계정명 추출, 여러 장 슬라이드는 실패할 수 있습니다.
- 인스타그램 앱에서 공유한 링크는 앱 안의 웹페이지로 열립니다. 공유한 즉시 백그라운드로 원본을 가져오는 것이 아닙니다.
- GIF는 MP4와 비교해 용량이 커지고 품질이 낮아집니다. GIF에는 소리가 없습니다.
- 원본 MP4 옵션 + 계정명 표시 설정 시 **재인코딩**되므로 MP4의 바이트 단위 원본과 같지 않습니다. 진짜 원본 저장은 '계정명 표시 끄기 + MP4' 입니다.
- 저작권자 권한이 없는 미디어의 재배포를 위한 도구가 아닙니다.

## Android Studio에서 APK 만들기

1. Android Studio 설치, Android SDK API 36 설치.
2. Android Studio에서 `IGHoldSaver` 폴더를 **Open**.
3. Gradle 동기화 후 **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. `app/build/outputs/apk/debug/app-debug.apk`를 스마트폰에 전송해 설치.

또는 Android SDK, Java 17, Gradle 8.11.1이 준비되었다면 프로젝트 루트에서:

```bash
gradle :app:assembleDebug
```

**GitHub Actions**: 휴대폰으로 APK를 내려받는 단계별 안내는 [`PHONE_BUILD_GUIDE.md`](PHONE_BUILD_GUIDE.md)를 참조하세요. `.github/workflows/build-apk.yml` 포함. 이 폴더를 GitHub 저장소에 업로드하고 **Actions → Build Android APK → Run workflow**를 누르면 Artifacts에서 `IGHoldSaver-debug-apk`를 받을 수 있습니다.

SDK/Gradle을 설치할 네트워크가 없던 작업 환경에서는 전체 APK 컴파일과 단말기 테스트를 수행하지 못했습니다. 따라서 빌드·실행에 필요한 조정이 있을 수 있습니다.

## 실제 사용

1. 앱 실행 → **인스타그램** 버튼.
2. 인스타그램 웹에서 원하는 게시물 보기(로그인 필요할 수 있음).
3. 게시물의 이미지/영상을 0.6초 이상 길게 누르기.
4. 옵션창에서 `계정명 표시`와 `MP4/GIF` 선택 → **저장**.
5. 갤러리의 `IGHoldSaver` 폴더에서 확인.

또는 인스타그램 앱에서 게시물 **공유 → 인스타 저장 도우미**를 선택하여 게시물 URL을 앱으로 전달. 게시물이 웹뷰로 열린 뒤 위 3단계부터 진행합니다.

## 소스 구조

- `app/src/main/java/com/example/igholdsaver/MainActivity.java`: WebView와 롱프레스 이벤트, 옵션창, 다운로드 큐, MP4 워터마크
- `app/src/main/java/com/example/igholdsaver/MediaFiles.java`: HTTPS 미디어 다운로드 및 검증, 이미지 워터마크, GIF 변환, MediaStore 갤러리 저장
- `app/src/main/java/com/example/igholdsaver/GifWriter.java`: 순수 Java GIF89a 인코딩
- `app/src/main/assets/inject.js`: DOM 터치 이벤트 기반 길게 누르기/원본 URL 선택
- `app/src/main/assets/home.html`: 첫 화면
- `.github/workflows/build-apk.yml`: GitHub Actions 디버그 APK 빌드

## 보안

- 앱은 HTTPS 인스타그램 계열 호스트에서만 파일을 내려받도록 제한합니다.
- 250 MB를 넘는 다운로드는 중단합니다.
- Android 10(API 29) 이상, 인터넷 권한만 요청합니다. 갤러리 저장은 MediaStore를 사용합니다.
- 비밀번호를 수집하는 별도 로그인 양식을 만들지 않았으며, 사용자의 Instagram 로그인을 자동화하지 않습니다.

## 테스트

GIF 인코더는 외부 라이브러리 없이 `javac` 및 Pillow로 디코딩 유효성을 검사했습니다. Android APK는 **빌드·실기기 테스트되지 않았으므로** 실제 동작을 보증하지 않습니다.
