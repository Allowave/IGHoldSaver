# 설치 가능한 APK 얻는 방법 (Android 휴대폰도 가능)

> ⚠️ 프로젝트는 소스 코드입니다. ZIP 압축을 `.apk`로 이름만 바꾸면 설치할 수 없습니다.
> APK는 Android SDK/Gradle로 **빌드 및 서명**해야 합니다. GitHub Actions가 자동으로 이 일을 하도록 설정했습니다.

## GitHub Actions에서 APK 빌드

1. GitHub 계정으로 새 저장소를 만듭니다. 이름은 `IGHoldSaver`, 공개/비공개 모두 가능.
2. 이 프로젝트의 **내용물 전체**를 저장소의 루트에 업로드해야 합니다. 즉 저장소 맨 위에 `.github`, `app`, `settings.gradle`, `build.gradle` 등이 보이도록 합니다. ZIP 파일만 업로드하지 마세요. `.github/workflows/build-apk.yml`도 반드시 포함해야 합니다.
3. 저장소의 **Actions** 탭에서 `Build Android APK`를 선택하고 **Run workflow**를 누릅니다. `main` 브랜치에 코드를 푸시했으면 자동 빌드도 실행됩니다.
4. 빌드가 녹색 체크로 완료되면 실행 상세 화면의 **Artifacts**에서 `IGHoldSaver-debug-apk`를 다운로드합니다. 다운로드된 ZIP의 압축을 풉니다.
5. 압축을 풀어 나온 `app-debug.apk`를 안드로이드 휴대폰에서 열어 설치합니다. 설치가 차단되면 Android 설정에서 해당 파일 앱/브라우저에 대해 **이 출처의 앱 설치 허용**을 켭니다.

### 주의
- GitHub Actions 아티팩트는 GitHub 로그인 후 다운로드해야 할 수 있습니다.
- `app-debug.apk`는 **디버그 서명 APK**로 설치는 가능하지만 Google Play 배포용 서명 버전은 아닙니다.
- 이 프로젝트는 실제 Android SDK 빌드/실기기 테스트가 아직 완료되지 않았으며 빌드 실패 시 오류 수정이 필요할 수 있습니다.
- 타사 인스타그램 앱을 길게 누르는 동작을 변경하는 것은 불가능하며, 이 앱의 웹뷰에서 길게 누르는 방식입니다.
- 미디어 다운로드는 인스타그램이 웹페이지에 노출한 사진/영상 URL에 한정되므로 일부 게시물에서 실패할 수 있습니다.

## PC가 있다면
Android Studio에서 프로젝트를 Open → Gradle Sync → Build → Build APK(s). 파일은 `app/build/outputs/apk/debug/app-debug.apk`에 만들어집니다.
