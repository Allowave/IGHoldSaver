(function () {
  'use strict';
  if (window.__IGHoldSaverHooked) return;
  window.__IGHoldSaverHooked = true;
  let timer = null, startX = 0, startY = 0, held = false, lastFired = 0;

  function visible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    const r = node.getBoundingClientRect();
    const style = window.getComputedStyle(node);
    return r.width > 95 && r.height > 95 && r.right > 0 && r.bottom > 0 &&
      r.left < window.innerWidth && r.top < window.innerHeight &&
      style.visibility !== 'hidden' && style.display !== 'none';
  }
  function findArticle(node) {
    let el = node && node.nodeType === 3 ? node.parentElement : node;
    if (!el || !el.closest) return null;
    let article = el.closest('article');
    if (article) return article;
    const media = el.closest('video,img');
    if (media) return media.closest('article') || media.parentElement;
    return el.closest('main') || el;
  }
  function usernameOf(article) {
    const candidates = [...article.querySelectorAll('header a[href], a[href^="/"]')];
    for (const a of candidates) {
      try {
        const path = new URL(a.href,location.href).pathname.split('/').filter(Boolean);
        if (path.length === 1 && /^[A-Za-z0-9._]{1,30}$/.test(path[0]) &&
          !['explore','reels','direct','accounts','stories','about','p','reel','tv'].includes(path[0])) return path[0];
      } catch(e) { /* ignore */ }
    }
    const meta = document.querySelector('meta[property="og:description"]');
    const str=meta ? meta.content : '';
    const m=str.match(/@([A-Za-z0-9._]{1,30})/);
    return m ? m[1] : 'unknown';
  }
  function extract(target) {
    const article = findArticle(target);
    if (!article) return null;
    const username = usernameOf(article);
    const media = [], used = new Set();
    const add=(element,kind)=>{
      if (!visible(element) || element.closest('header') || element.closest('footer')) return;
      let url=element.currentSrc || element.src || '';
      if (!url && kind === 'video') {
        const src=element.querySelector('source[src]');
        if(src) url=src.src;
      }
      if (!url || !/^https:\/\//i.test(url) || used.has(url)) return;
      if (!/(?:instagram\.com|cdninstagram\.com|fbcdn\.net)(?=[:/]|$)/i.test(new URL(url).hostname)) return;
      used.add(url);media.push({url:url,type:kind});
    };
    // Video gets priority over its poster image.
    [...article.querySelectorAll('video')].forEach(e=>add(e,'video'));
    [...article.querySelectorAll('img')].forEach(e=>{
      if (e.closest('a[role="link"]') && (e.width < 180 || e.height < 180)) return;
      add(e,'image');
    });
    // On detail screens with only an image and no article wrapper, use touched media.
    if (!media.length) {
      const actual=target.closest && target.closest('img,video');
      if(actual) add(actual,actual.tagName.toLowerCase()==='video'?'video':'image');
    }
    return {username,media:media.slice(0,20)};
  }
  function fire(target) {
    if (Date.now()-lastFired<1200) return;
    lastFired=Date.now(); held=true;
    let packet=extract(target);
    if (!packet) packet={username:'unknown',media:[]};
    try { window.IgSaver.onLongPress(JSON.stringify(packet)); } catch(ex) { console.log('Saver unavailable',ex); }
  }
  function cancel() { if(timer!==null){clearTimeout(timer);timer=null;} }
  document.addEventListener('pointerdown', e=>{
    if(e.pointerType!=='touch' && e.pointerType!=='pen') return;
    cancel();held=false;
    startX=e.clientX;startY=e.clientY;
    const original=e.target;
    timer=setTimeout(()=>{timer=null;fire(original);},620);
  },{passive:true,capture:true});
  document.addEventListener('pointermove',e=>{
    if(Math.abs(e.clientX-startX)>16 || Math.abs(e.clientY-startY)>16) cancel();
  },{passive:true,capture:true});
  ['pointerup','pointercancel','touchcancel','scroll'].forEach(type=>
    document.addEventListener(type,cancel,{passive:true,capture:true}));
  document.addEventListener('contextmenu',e=>{
    const node=e.target;
    if(node.closest && (node.closest('article') || node.closest('img,video'))) {
      e.preventDefault();
      if(!held) fire(node);
    }
  },true);
  console.log('IGHoldSaver: press and hold a post to save');
})();
