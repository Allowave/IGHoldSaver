package com.example.igholdsaver;

import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/** Tiny dependency-free GIF89a animation writer. Frames are quantized to a fixed RGB332 palette. */
public final class GifWriter implements Closeable {
    private final OutputStream out;
    private final int width, height;
    private boolean closed;

    public GifWriter(OutputStream out, int width, int height) throws IOException {
        if (width < 1 || height < 1 || width > 65535 || height > 65535) throw new IllegalArgumentException("GIF dimensions");
        this.out = out;
        this.width = width;
        this.height = height;
        writeAscii("GIF89a");
        u16(width); u16(height);
        u8(0xF7); u8(0); u8(0);
        for (int r = 0; r < 8; r++) for (int g = 0; g < 8; g++) for (int b = 0; b < 4; b++) {
            u8((r * 255) / 7);
            u8((g * 255) / 7);
            u8((b * 255) / 3);
        }
        // Loop forever (Netscape extension).
        u8(0x21); u8(0xFF); u8(11); writeAscii("NETSCAPE2.0");
        u8(3); u8(1); u16(0); u8(0);
    }

    public void addFrame(int[] argb, int delayCentiseconds) throws IOException {
        if (closed) throw new IOException("closed");
        if (argb.length != width * height) throw new IllegalArgumentException("Frame size");
        byte[] indices = new byte[argb.length];
        for (int i=0; i<argb.length; i++) {
            int x=argb[i];
            indices[i] = (byte) (((x >>> 16) & 0xE0) | (((x >>> 8) & 0xE0) >>> 3) | ((x & 0xC0) >>> 6));
        }
        u8(0x21); u8(0xF9); u8(4); u8(0x00);
        u16(Math.max(1, Math.min(65535, delayCentiseconds)));
        u8(0); u8(0);
        u8(0x2C); u16(0); u16(0); u16(width); u16(height); u8(0);
        u8(8); // 8-bit LZW palette indices
        lzw(indices);
    }

    private void lzw(byte[] pixels) throws IOException {
        final int clear=256, end=257;
        int codeSize=9, nextCode=258;
        Map<Integer, Integer> dict=new HashMap<>(4096);
        BitSink sink=new BitSink();
        sink.code(clear, codeSize);
        int prefix = pixels[0] & 255;
        for (int i=1; i<pixels.length; i++) {
            int c=pixels[i] & 255;
            int key=(prefix << 8) | c;
            Integer known=dict.get(key);
            if (known != null) { prefix=known; continue; }
            sink.code(prefix, codeSize);
            if (nextCode <= 4095) {
                dict.put(key, nextCode++);
                // GIF code size increases when dictionary is large enough for the next code.
                if (nextCode > (1 << codeSize) && codeSize < 12) codeSize++;
            } else {
                sink.code(clear, codeSize);
                dict.clear();
                codeSize=9;
                nextCode=258;
            }
            prefix=c;
        }
        sink.code(prefix, codeSize);
        sink.code(end, codeSize);
        sink.flush();
    }

    private final class BitSink {
        int accum, bits;
        final byte[] buffer=new byte[255];
        int length;
        void code(int code, int size) throws IOException {
            accum |= code << bits;
            bits += size;
            while (bits >= 8) {
                push((byte) accum);
                accum >>>= 8;
                bits -= 8;
            }
        }
        void push(byte c) throws IOException {
            buffer[length++] = c;
            if (length == buffer.length) block();
        }
        void block() throws IOException {
            if (length > 0) { u8(length); out.write(buffer,0,length); length=0; }
        }
        void flush() throws IOException {
            if (bits > 0) push((byte)accum);
            block();
            u8(0);
        }
    }

    private void u8(int x) throws IOException { out.write(x & 255); }
    private void u16(int x) throws IOException {u8(x);u8(x >>> 8);}
    private void writeAscii(String s) throws IOException {out.write(s.getBytes(java.nio.charset.StandardCharsets.US_ASCII));}
    @Override public void close() throws IOException {
        if (!closed) { closed=true; u8(0x3B); out.flush(); }
    }
}
