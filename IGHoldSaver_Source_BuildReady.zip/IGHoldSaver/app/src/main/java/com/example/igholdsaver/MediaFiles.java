package com.example.igholdsaver;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

final class MediaFiles {
    static final long MAX_BYTES = 250L * 1024 * 1024;
    private MediaFiles() { }

    static boolean isTrustedMediaUrl(String value) {
        try {
            Uri uri = Uri.parse(value);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) return false;
            String host = uri.getHost().toLowerCase(Locale.ROOT);
            return host.equals("instagram.com") || host.endsWith(".instagram.com")
                    || host.equals("cdninstagram.com") || host.endsWith(".cdninstagram.com")
                    || host.equals("fbcdn.net") || host.endsWith(".fbcdn.net");
        } catch (RuntimeException ex) { return false; }
    }

    static boolean isInstagramPage(String value) {
        try {
            Uri uri = Uri.parse(value);
            String host = uri.getHost();
            return "https".equalsIgnoreCase(uri.getScheme()) && host != null &&
                (host.equalsIgnoreCase("instagram.com") || host.toLowerCase(Locale.ROOT).endsWith(".instagram.com"));
        } catch (RuntimeException ex) { return false; }
    }

    static File fetch(Context context, String address, String userAgent) throws IOException {
        if (!isTrustedMediaUrl(address)) throw new IOException("허용되지 않는 미디어 주소입니다.");
        File target = File.createTempFile("igdownload_", ".tmp", context.getCacheDir());
        boolean success = false;
        try {
            URL next = new URL(address);
            for (int hops = 0; hops < 6; hops++) {
                if (!isTrustedMediaUrl(next.toString())) throw new IOException("외부 서버로 리디렉션되어 차단했습니다.");
                HttpURLConnection conn = (HttpURLConnection) next.openConnection();
                conn.setInstanceFollowRedirects(false);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestProperty("User-Agent", userAgent);
                conn.setRequestProperty("Referer", "https://www.instagram.com/");
                String cookie = CookieManager.getInstance().getCookie(next.toString());
                if (cookie != null && !cookie.isEmpty()) conn.setRequestProperty("Cookie", cookie);
                try {
                    int code = conn.getResponseCode();
                    if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                        String location = conn.getHeaderField("Location");
                        if (location == null) throw new IOException("이동 주소가 없습니다.");
                        next = new URL(next, location);
                        continue;
                    }
                    if (code != 200) throw new IOException("다운로드 실패: 서버 응답 " + code);
                    if (conn.getContentLengthLong() > MAX_BYTES) throw new IOException("파일이 너무 큽니다 (250MB 초과).");
                    String mime = conn.getContentType();
                    if (mime != null && !mime.toLowerCase(Locale.ROOT).matches("(image|video)/.*|application/octet-stream.*"))
                        throw new IOException("미디어 파일이 아닌 응답입니다.");
                    try (InputStream in=conn.getInputStream(); OutputStream out=new FileOutputStream(target)) {
                        byte[] buffer=new byte[64*1024]; long count=0; int n;
                        while ((n=in.read(buffer)) != -1) {
                            count += n;
                            if (count > MAX_BYTES) throw new IOException("파일이 너무 큽니다.");
                            out.write(buffer, 0, n);
                        }
                        if (count == 0) throw new IOException("빈 파일입니다.");
                    }
                    success=true;
                    return target;
                } finally { conn.disconnect(); }
            }
            throw new IOException("리디렉션 횟수가 너무 많습니다.");
        } finally { if (!success) target.delete(); }
    }

    static String cleanUser(String user) {
        if (user == null) return "unknown";
        String result = user.trim().replaceFirst("^@", "");
        return result.matches("[A-Za-z0-9._]{1,30}") ? result : "unknown";
    }

    static void drawAttribution(Canvas canvas, String user, int width, int height) {
        String label = "@" + cleanUser(user);
        float size = Math.max(13, Math.min(width, height) * 0.048f);
        float x = Math.max(12, width * 0.035f);
        float y = height - Math.max(16, height * 0.04f);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(size);
        p.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
        float padding = size * 0.55f;
        float textWidth=p.measureText(label);
        p.setColor(Color.argb(185, 0, 0, 0));
        canvas.drawRoundRect(new RectF(x-padding/2, y-size-padding/2, x+textWidth+padding/2, y+padding/2), size*0.3f, size*0.3f, p);
        p.setColor(Color.WHITE);
        canvas.drawText(label, x, y, p);
    }

    static File watermarkImage(Context context, File file, String user) throws IOException {
        BitmapFactory.Options opts=new BitmapFactory.Options();
        opts.inJustDecodeBounds=true;
        BitmapFactory.decodeFile(file.getPath(), opts);
        int max = Math.max(opts.outWidth, opts.outHeight);
        opts.inSampleSize = Math.max(1, (int)Math.ceil(max/4096.0));
        opts.inJustDecodeBounds=false;
        Bitmap bitmap=BitmapFactory.decodeFile(file.getPath(), opts);
        if (bitmap==null) throw new IOException("이미지를 열 수 없습니다.");
        File output = File.createTempFile("igimage_", ".jpg", context.getCacheDir());
        try {
            Bitmap mutable=bitmap.copy(Bitmap.Config.ARGB_8888, true);
            if (mutable == null) throw new IOException("이미지 처리 실패");
            try {
                drawAttribution(new Canvas(mutable), user, mutable.getWidth(), mutable.getHeight());
                try (OutputStream os=new FileOutputStream(output)) {
                    if (!mutable.compress(Bitmap.CompressFormat.JPEG, 94, os)) throw new IOException("JPEG 처리 실패");
                }
            } finally { mutable.recycle(); }
            return output;
        } finally { bitmap.recycle(); }
    }

    static File convertGif(Context context, File file, String user, boolean watermark) throws IOException {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        File gif=File.createTempFile("ig_gif_", ".gif", context.getCacheDir());
        boolean okay=false;
        try {
            r.setDataSource(file.getAbsolutePath());
            String ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (ms == null) throw new IOException("영상 길이를 확인할 수 없습니다.");
            long durationMs = Math.min(12000, Long.parseLong(ms));
            if (durationMs <= 0) throw new IOException("영상 길이가 올바르지 않습니다.");
            int origW = Integer.parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int origH = Integer.parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            if (origW <= 0 || origH <= 0) throw new IOException("영상 크기를 확인할 수 없습니다.");
            int w=origW, h=origH;
            float scale = Math.min(1f, 480f/Math.max(w,h));
            w=Math.max(2, Math.round(w*scale)); h=Math.max(2, Math.round(h*scale));
            int fps=6, frames=Math.max(1, (int)Math.ceil(durationMs * fps / 1000.0));
            int[] pixels=new int[w*h];
            try (OutputStream out=new FileOutputStream(gif); GifWriter writer=new GifWriter(out,w,h)) {
                int actualFrames=0;
                for (int i=0; i<frames; i++) {
                    long us=(long)i*1000000/fps;
                    Bitmap b=r.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, w, h);
                    if (b==null) continue;
                    try {
                        Bitmap frame=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                        try {
                            Canvas canvas=new Canvas(frame);
                            canvas.drawBitmap(b,null,new android.graphics.Rect(0,0,w,h),new Paint(Paint.FILTER_BITMAP_FLAG));
                            if (watermark) drawAttribution(canvas,user,w,h);
                            frame.getPixels(pixels,0,w,0,0,w,h);
                            writer.addFrame(pixels, 100/fps);
                            actualFrames++;
                        } finally { frame.recycle(); }
                    } finally { b.recycle(); }
                }
                if (actualFrames == 0) throw new IOException("영상 프레임을 읽을 수 없습니다.");
            }
            okay=true; return gif;
        } catch (NumberFormatException ex) { throw new IOException("영상 정보가 올바르지 않습니다.", ex); }
        finally {r.release(); if(!okay)gif.delete();}
    }

    static Uri saveToGallery(Context context, File file, String mime, String fileName) throws IOException {
        boolean video=mime.startsWith("video/");
        ContentResolver resolver=context.getContentResolver();
        Uri collection=video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        ContentValues cv=new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME,fileName);
        cv.put(MediaStore.MediaColumns.MIME_TYPE,mime);
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH,(video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES) + "/IGHoldSaver");
        cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri dest=resolver.insert(collection,cv);
        if(dest==null) throw new IOException("갤러리 공간을 만들지 못했습니다.");
        boolean success=false;
        try (InputStream in=new FileInputStream(file); OutputStream out=resolver.openOutputStream(dest)) {
            if(out == null) throw new IOException("갤러리 파일을 열 수 없습니다.");
            byte[] buf=new byte[65536]; int n;
            while((n=in.read(buf))!=-1) out.write(buf,0,n);
            success=true;
        } finally {
            if (!success) resolver.delete(dest,null,null);
        }
        cv.clear(); cv.put(MediaStore.MediaColumns.IS_PENDING,0);
        resolver.update(dest,cv,null,null);
        return dest;
    }
}
