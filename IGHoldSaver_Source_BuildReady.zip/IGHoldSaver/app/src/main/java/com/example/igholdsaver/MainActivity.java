package com.example.igholdsaver;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.StaticOverlaySettings;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Personal media saver UI. Only extracts visible media from pages accessed by the user. */
public final class MainActivity extends Activity {
    private static final String HOME="file:///android_asset/home.html";
    private final ExecutorService jobs=Executors.newSingleThreadExecutor();
    private WebView browser;
    private SharedPreferences prefs;
    private String injectScript;
    private String userAgent;
    private boolean busy;
    private Transformer transformer;

    static final class FoundMedia {
        String url;
        boolean video;
        FoundMedia(String url,boolean video) {this.url=url;this.video=video;}
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(15,18,29));
        getWindow().setNavigationBarColor(Color.rgb(15,18,29));
        prefs=getSharedPreferences("options",MODE_PRIVATE);
        try (java.io.InputStream in=getAssets().open("inject.js")) {
            java.io.ByteArrayOutputStream buffer=new java.io.ByteArrayOutputStream();
            byte[] block=new byte[8192];int count;
            while((count=in.read(block))!=-1)buffer.write(block,0,count);
            injectScript=buffer.toString("UTF-8");
        } catch(IOException e) {injectScript="";}
        setupUi();
        String shared=extractSharedUrl(getIntent());
        if(shared != null) browser.loadUrl(shared);
        else browser.loadUrl(HOME);
    }

    private int dp(int x) {return Math.round(getResources().getDisplayMetrics().density*x);}
    private Button button(String text, float weight) {
        Button b=new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(40,49,79)));
        b.setLayoutParams(new LinearLayout.LayoutParams(0,dp(52),weight));
        return b;
    }
    private void setupUi() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(15,18,29));
        TextView top=new TextView(this);
        top.setText("  ◉  인스타 저장 도우미");
        top.setTextSize(18); top.setTextColor(Color.WHITE);top.setGravity(Gravity.CENTER_VERTICAL);
        top.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(50)));
        root.addView(top);
        browser=new WebView(this);
        browser.setBackgroundColor(Color.rgb(15,18,29));
        browser.getSettings().setJavaScriptEnabled(true);
        browser.getSettings().setDomStorageEnabled(true);
        browser.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        browser.getSettings().setAllowFileAccess(false);
        browser.getSettings().setAllowContentAccess(false);
        browser.getSettings().setMediaPlaybackRequiresUserGesture(false);
        browser.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        userAgent=browser.getSettings().getUserAgentString();
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser,true);
        browser.addJavascriptInterface(new Bridge(),"IgSaver");
        browser.setWebChromeClient(new WebChromeClient());
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                String target=request.getUrl().toString();
                if (MediaFiles.isInstagramPage(target)) return false;
                if (target.equals(HOME)) return false;
                if ("https".equals(request.getUrl().getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW,request.getUrl()));
                }
                return true;
            }
            @Override public void onPageFinished(WebView view,String url) {
                if (MediaFiles.isInstagramPage(url) && !injectScript.isEmpty())
                    view.evaluateJavascript(injectScript, null);
            }
        });
        root.addView(browser,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar=new LinearLayout(this); bar.setPadding(dp(4),dp(3),dp(4),dp(3));
        Button insta=button("인스타그램",1), link=button("링크 열기",1), settings=button("옵션",0.8f), home=button("홈",0.6f);
        insta.setOnClickListener(v->browser.loadUrl("https://www.instagram.com/"));
        link.setOnClickListener(v->promptUrl());
        settings.setOnClickListener(v->showSettings());
        home.setOnClickListener(v->browser.loadUrl(HOME));
        bar.addView(insta);bar.addView(link);bar.addView(settings);bar.addView(home);
        root.addView(bar);
        setContentView(root);
    }

    private String extractSharedUrl(Intent intent) {
        if(intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return null;
        if (!"text/plain".equals(intent.getType())) return null;
        String text=intent.getStringExtra(Intent.EXTRA_TEXT);
        if(text==null) return null;
        Matcher m=Pattern.compile("https://(?:www\\.)?instagram\\.com/(?:p|reel|reels|tv)/[A-Za-z0-9_-]+[^\\s]*").matcher(text);
        if (m.find()) return m.group();
        return null;
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url=extractSharedUrl(intent);
        if(url!=null && browser!=null) browser.loadUrl(url);
    }
    private void promptUrl() {
        EditText input=new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        input.setSingleLine(true);input.setHint("https://www.instagram.com/p/...");
        LinearLayout layout=new LinearLayout(this);layout.setPadding(dp(22),dp(10),dp(22),0);
        layout.addView(input,new LinearLayout.LayoutParams(-1,-2));
        new AlertDialog.Builder(this).setTitle("게시물 링크 열기").setView(layout)
          .setPositiveButton("열기",(d,w)->{
              String u=input.getText().toString().trim();
              if(MediaFiles.isInstagramPage(u))browser.loadUrl(u);
              else toast("인스타그램 HTTPS 링크만 가능합니다.");
          }).setNegativeButton("취소",null).show();
    }
    private void showSettings() {
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(24),dp(12),dp(24),dp(12));
        CheckBox watermark=new CheckBox(this);watermark.setText("계정명 @username 표시");
        watermark.setChecked(prefs.getBoolean("watermark",true));
        p.addView(watermark);
        TextView format=new TextView(this);format.setText("영상 다운로드 방식");format.setPadding(0,dp(10),0,dp(4));p.addView(format);
        RadioGroup group=new RadioGroup(this);
        RadioButton mp4=new RadioButton(this);mp4.setText("원본 MP4 (영상·음성 유지)");mp4.setId(10);
        RadioButton gif=new RadioButton(this);gif.setText("GIF (최대 12초·무음·6fps)");gif.setId(11);
        group.addView(mp4);group.addView(gif);group.check(prefs.getBoolean("gif",false)?11:10);
        p.addView(group);
        new AlertDialog.Builder(this).setTitle("다운로드 기본 옵션").setView(p)
        .setPositiveButton("저장",(dialog,which)->prefs.edit().putBoolean("watermark",watermark.isChecked()).putBoolean("gif",group.getCheckedRadioButtonId()==11).apply())
        .setNegativeButton("취소",null).show();
    }

    private class Bridge {
        @JavascriptInterface public void onLongPress(String json) {
            if(json==null || json.length()>50000) return;
            runOnUiThread(()->handleLongPress(json));
        }
        @JavascriptInterface public void openInstagram() {
            runOnUiThread(()->browser.loadUrl("https://www.instagram.com/"));
        }
        @JavascriptInterface public void enterLink() {
            runOnUiThread(()->promptUrl());
        }
    }
    private void handleLongPress(String json) {
        if(busy) {toast("다른 다운로드가 진행 중입니다.");return;}
        try {
            JSONObject data=new JSONObject(json);
            String user=MediaFiles.cleanUser(data.optString("username","unknown"));
            JSONArray arr=data.optJSONArray("media");
            List<FoundMedia> media=new ArrayList<>();
            if(arr != null) for(int i=0;i<Math.min(arr.length(),20);i++) {
                JSONObject item=arr.optJSONObject(i);
                if(item==null)continue;
                String url=item.optString("url","");
                if(MediaFiles.isTrustedMediaUrl(url)) media.add(new FoundMedia(url, "video".equals(item.optString("type"))));
            }
            if(media.isEmpty()){
                new AlertDialog.Builder(this).setTitle("원본 주소를 찾지 못했습니다")
                  .setMessage("인스타그램에서 미디어 주소를 공개하지 않았거나 영상이 blob 형태일 수 있습니다. 다른 게시물 또는 공유 링크로 다시 시도해 주세요.")
                  .setPositiveButton("확인",null).show();return;
            }
            showSaveDialog(user,media);
        }catch(Exception ex){toast("게시물 정보를 읽지 못했습니다.");}
    }

    private void showSaveDialog(String user,List<FoundMedia> found) {
        LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(24),dp(12),dp(24),dp(10));
        TextView desc=new TextView(this);
        int vcount=0;for(FoundMedia f:found) if(f.video)vcount++;
        desc.setText("게시자: @"+user+"\n사진 "+(found.size()-vcount)+"개 · 영상 "+vcount+"개\n선택한 미디어를 갤러리에 저장합니다.");
        panel.addView(desc);
        CheckBox mark=new CheckBox(this);mark.setText("이미지·영상에 계정명 표시");
        mark.setChecked(prefs.getBoolean("watermark",true));panel.addView(mark);
        RadioGroup format=new RadioGroup(this);
        RadioButton original=new RadioButton(this);original.setText("영상은 원본 MP4");original.setId(20);
        RadioButton gif=new RadioButton(this);gif.setText("영상은 GIF (최대 12초, 음성 제외)");gif.setId(21);
        format.addView(original);format.addView(gif);format.check(prefs.getBoolean("gif",false)?21:20);
        panel.addView(format);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("다운로드")
                .setView(panel).setNegativeButton("취소",null)
                .setPositiveButton("저장",(di,which)->{
                    boolean w=mark.isChecked(); boolean isGif=format.getCheckedRadioButtonId()==21;
                    prefs.edit().putBoolean("watermark",w).putBoolean("gif",isGif).apply();
                    saveMedia(user,new ArrayList<>(found),w,isGif);
                }).create();
        dialog.show();
    }

    private void saveMedia(String user,List<FoundMedia> found,boolean watermark,boolean asGif) {
        if(busy) return;
        busy=true;
        toast("다운로드를 시작했습니다 ("+found.size()+"개)");
        jobs.execute(()->{
            int completed=0;
            for(int i=0;i<found.size();i++) {
                FoundMedia item=found.get(i);
                File raw=null,processed=null;
                try {
                    raw=MediaFiles.fetch(this,item.url,userAgent);
                    String extension,mime;
                    if(item.video) {
                        if(asGif) {
                            processed=MediaFiles.convertGif(this,raw,user,watermark);
                            extension="gif";mime="image/gif";
                        } else if(watermark) {
                            processed=overlayVideo(raw,user);
                            extension="mp4";mime="video/mp4";
                        } else {
                            processed=raw;extension="mp4";mime="video/mp4";
                        }
                    } else {
                        if(watermark) {
                            processed=MediaFiles.watermarkImage(this,raw,user);
                            extension="jpg";mime="image/jpeg";
                        } else {
                            extension=guessImageExtension(raw);
                            mime="webp".equals(extension)?"image/webp":"png".equals(extension)?"image/png":"image/jpeg";
                            processed=raw;
                        }
                    }
                    String name="IG_"+user+"_"+System.currentTimeMillis()+"_"+(i+1)+"."+extension;
                    MediaFiles.saveToGallery(this,processed,mime,name);
                    completed++;
                    int idx=i+1;
                    runOnUiThread(()->toast("저장 완료 ("+idx+"/"+found.size()+")"));
                } catch(Exception e) {
                    String message=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
                    runOnUiThread(()->new AlertDialog.Builder(this).setTitle("저장 실패").setMessage(message)
                            .setPositiveButton("확인",null).show());
                } finally {
                    if(processed!=null && !processed.equals(raw)) processed.delete();
                    if(raw!=null) raw.delete();
                }
            }
            int good=completed;
            runOnUiThread(()->{busy=false;toast("저장 완료: "+good+"/"+found.size()+"개 · 갤러리 IGHoldSaver 폴더");});
        });
    }

    private static String guessImageExtension(File file) throws IOException {
        byte[] head=new byte[16];
        try(FileInputStream in=new FileInputStream(file)) { if(in.read(head)<12) throw new IOException("이미지 파일이 너무 짧습니다.");}
        if((head[0]&255)==255 && (head[1]&255)==216)return "jpg";
        if((head[0]&255)==137 && head[1]==80 && head[2]==78 && head[3]==71)return "png";
        if(head[0]==82&&head[1]==73&&head[2]==70&&head[3]==70&&head[8]==87&&head[9]==69&&head[10]==66&&head[11]==80)return "webp";
        throw new IOException("지원하지 않는 이미지 형식입니다.");
    }

    private File overlayVideo(File raw,String user) throws Exception {
        File output=File.createTempFile("ig_overlay_", ".mp4", getCacheDir());
        // Transformer must start and invoke callbacks on the main thread.
        CountDownLatch latch=new CountDownLatch(1);
        AtomicReference<Exception> error=new AtomicReference<>();
        runOnUiThread(()->{
            try {
                Bitmap badge=Bitmap.createBitmap(480,94,Bitmap.Config.ARGB_8888);
                Canvas canvas=new Canvas(badge);
                Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
                paint.setColor(Color.argb(205, 0, 0, 0));
                canvas.drawRoundRect(0, 0, 480, 94, 21, 21, paint);
                paint.setColor(Color.WHITE);
                paint.setTextSize(42);
                paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
                canvas.drawText("@"+MediaFiles.cleanUser(user), 22, 64, paint);
                StaticOverlaySettings settings=new StaticOverlaySettings.Builder()
                    .setBackgroundFrameAnchor(-0.92f,-0.85f)
                    .setOverlayFrameAnchor(-1f,-1f)
                    .setScale(0.55f,0.55f).build();
                BitmapOverlay overlay=BitmapOverlay.createStaticBitmapOverlay(badge, settings);
                Effects effects=new Effects(Collections.emptyList(),
                  Collections.singletonList(new OverlayEffect(Collections.singletonList(overlay))));
                EditedMediaItem edit=new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(raw)))
                        .setEffects(effects).build();
                transformer=new Transformer.Builder(this).addListener(new Transformer.Listener() {
                    @Override public void onCompleted(Composition composition,ExportResult result) {
                        badge.recycle(); transformer=null;latch.countDown();
                    }
                    @Override public void onError(Composition composition,ExportResult result,ExportException cause) {
                        error.set(cause);badge.recycle();transformer=null;latch.countDown();
                    }
                }).build();
                transformer.start(edit,output.getAbsolutePath());
            }catch(Exception ex){error.set(ex);latch.countDown();}
        });
        if(!latch.await(5,TimeUnit.MINUTES)){
            runOnUiThread(()->{if(transformer!=null){transformer.cancel();transformer=null;}});
            output.delete();throw new IOException("영상 변환 제한 시간을 초과했습니다.");
        }
        if(error.get()!=null){output.delete();throw error.get();}
        return output;
    }

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed() {
        if(browser!=null && browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(transformer!=null) transformer.cancel();
        jobs.shutdownNow();
        if(browser!=null) browser.destroy();
        super.onDestroy();
    }
}
